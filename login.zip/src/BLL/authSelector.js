export const authSelector = state => state.auth.isAuth;
export const loginSelector = state => state.auth.userInfo.login;

