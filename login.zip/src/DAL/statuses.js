export const statuses = {
    NOT_INITIALIZED: 'NOT_INIT',
    IN_PROGRESS: 'IN_PROGRESS',
    SUCCESS: 'SUCCESS',
    ERROR: 'ERROR'
}